import numpy as np
import os

ab_path = 'c:/Users/a0102/OneDrive/Desktop/STFT/ResNet18/abnormal_image/abnormal_image.npy'
norm_path = 'c:/Users/a0102/OneDrive/Desktop/STFT/ResNet18/normal_image/normal_image.npy'
save_dir = 'c:/Users/a0102/OneDrive/Desktop/STFT/ResNet18/dataset'

os.makedirs(save_dir, exist_ok=True)

def create_windows(data, window_size=64, step_size=16):
    """
    (Freq, Time, Channels) 형태의 거대 텐서를 (Channels, Freq, Time_Window) 단위로 조각냅니다.
    """
    time_len = data.shape[1]
    windows = []
    for start in range(0, time_len - window_size + 1, step_size):
        end = start + window_size
        window = data[:, start:end, :] # (65, 64, 6)
        
        # PyTorch의 Conv2d는 (Batch, Channels, Height, Width)를 기대하므로
        # (Freq, Time, Channels) -> (Channels, Freq, Time) 으로 변경합니다.
        window = np.transpose(window, (2, 0, 1)) # (6, 65, 64)
        windows.append(window)
    return np.array(windows)

print("Loading raw tensors...")
ab_data = np.load(ab_path)
norm_data = np.load(norm_path)

print("Slicing Normal data (Label 0)...")
X_normal = create_windows(norm_data, window_size=64, step_size=16)
y_normal = np.zeros(len(X_normal), dtype=np.int64)

print("Slicing Abnormal data (Label 1)...")
X_abnormal = create_windows(ab_data, window_size=64, step_size=16)
y_abnormal = np.ones(len(X_abnormal), dtype=np.int64)

# 정상과 비정상 데이터 합치기
X = np.concatenate((X_normal, X_abnormal), axis=0).astype(np.float32)
y = np.concatenate((y_normal, y_abnormal), axis=0)

print(f"\nDataset Preparation Complete!")
print(f"X_train shape: {X.shape} (N_samples, Channels, Freq, Time)")
print(f"y_train shape: {y.shape}")

np.save(os.path.join(save_dir, 'X_train.npy'), X)
np.save(os.path.join(save_dir, 'y_train.npy'), y)
print(f"Saved chunks to {save_dir}/")
