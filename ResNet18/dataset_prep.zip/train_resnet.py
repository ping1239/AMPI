import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from torchvision import models
import matplotlib.pyplot as plt

# 1. 환경 설정
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

dataset_dir = 'c:/Users/a0102/OneDrive/Desktop/STFT/ResNet18/dataset'
save_dir = 'c:/Users/a0102/OneDrive/Desktop/STFT/ResNet18/model_output'
os.makedirs(save_dir, exist_ok=True)

# 2. 데이터 로드 및 PyTorch DataLoader 생성
print("Loading dataset...")
X = np.load(os.path.join(dataset_dir, 'X_train.npy'))
y = np.load(os.path.join(dataset_dir, 'y_train.npy'))

# NaN 값이 있는지 확인하고 0으로 대체
if np.isnan(X).any():
    print("Warning: NaN found in data. Replacing with 0.0")
    X = np.nan_to_num(X, nan=0.0)

# 파이토치 텐서로 변환
X_tensor = torch.tensor(X, dtype=torch.float32)
y_tensor = torch.tensor(y, dtype=torch.long)

dataset = TensorDataset(X_tensor, y_tensor)

# [핵심 수정] 무작위 분할(Data Leakage)을 막기 위해 시간순(순차적)으로 80:20 분할
# 정상(0)과 급가속(1) 인덱스를 각각 찾습니다.
idx_0 = torch.where(y_tensor == 0)[0]
idx_1 = torch.where(y_tensor == 1)[0]

split_0 = int(0.8 * len(idx_0))
split_1 = int(0.8 * len(idx_1))

# 각 클래스별로 앞부분 80%는 학습, 뒷부분 20%는 검증으로 잘라냅니다.
train_idx = torch.cat((idx_0[:split_0], idx_1[:split_1]))
val_idx = torch.cat((idx_0[split_0:], idx_1[split_1:]))

from torch.utils.data import Subset
train_dataset = Subset(dataset, train_idx)
val_dataset = Subset(dataset, val_idx)

train_size = len(train_dataset)
val_size = len(val_dataset)

train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=16, shuffle=False)
print(f"Train samples: {train_size}, Val samples: {val_size}")

# 3. 6채널 입력용 ResNet-18 모델 정의
def get_custom_resnet18():
    # PyTorch의 기본 ResNet-18 불러오기 (사전학습 가중치 없이 구조만)
    model = models.resnet18(weights=None)
    
    # [핵심 개조 1] 입력 채널을 3(RGB)에서 6(로봇 축 개수)으로 변경
    original_conv1 = model.conv1
    model.conv1 = nn.Conv2d(6, original_conv1.out_channels, 
                            kernel_size=original_conv1.kernel_size, 
                            stride=original_conv1.stride, 
                            padding=original_conv1.padding, 
                            bias=original_conv1.bias)
    
    # [핵심 개조 2] 최종 출력 클래스를 1000개에서 2개(정상 0, 급가속 1)로 변경
    num_ftrs = model.fc.in_features
    model.fc = nn.Linear(num_ftrs, 2)
    
    return model

model = get_custom_resnet18().to(device)

# 4. 손실 함수 및 옵티마이저
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 5. 모델 학습 루프
num_epochs = 15
train_losses, val_losses = [], []
train_accs, val_accs = [], []

print("Starting training...")
best_val_acc = 0.0

for epoch in range(num_epochs):
    # --- Training ---
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    
    for inputs, labels in train_loader:
        inputs, labels = inputs.to(device), labels.to(device)
        
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
        
    epoch_train_loss = running_loss / len(train_loader)
    epoch_train_acc = 100 * correct / total
    
    # --- Validation ---
    model.eval()
    val_loss = 0.0
    correct = 0
    total = 0
    
    with torch.no_grad():
        for inputs, labels in val_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            
            val_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
    epoch_val_loss = val_loss / len(val_loader)
    epoch_val_acc = 100 * correct / total
    
    train_losses.append(epoch_train_loss)
    val_losses.append(epoch_val_loss)
    train_accs.append(epoch_train_acc)
    val_accs.append(epoch_val_acc)
    
    print(f"Epoch [{epoch+1}/{num_epochs}] "
          f"Train Loss: {epoch_train_loss:.4f}, Train Acc: {epoch_train_acc:.2f}% | "
          f"Val Loss: {epoch_val_loss:.4f}, Val Acc: {epoch_val_acc:.2f}%")
          
    # 최고 성능 모델 저장
    if epoch_val_acc >= best_val_acc:
        best_val_acc = epoch_val_acc
        torch.save(model.state_dict(), os.path.join(save_dir, 'resnet18_xarm_best.pth'))

print("Training finished!")
print(f"Best Validation Accuracy: {best_val_acc:.2f}%")

# 6. 학습 결과 그래프 저장
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(train_losses, label='Train Loss')
plt.plot(val_losses, label='Validation Loss')
plt.title('Loss over Epochs')
plt.xlabel('Epochs')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(train_accs, label='Train Accuracy')
plt.plot(val_accs, label='Validation Accuracy')
plt.title('Accuracy over Epochs')
plt.xlabel('Epochs')
plt.legend()

plt.tight_layout()
plt.savefig(os.path.join(save_dir, 'training_history.png'))
print(f"Graph saved to {save_dir}/training_history.png")
